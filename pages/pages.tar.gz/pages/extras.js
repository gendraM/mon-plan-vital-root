import React from 'react';

const Extras = () => {
    return (
        <div>
            <h1>Synthèse des Extras</h1>
            <p>Voici un aperçu des extras que vous avez déclarés.</p>
            {/* Ajoutez ici la logique pour afficher les extras */}
        </div>
    );
};

export default Extras;