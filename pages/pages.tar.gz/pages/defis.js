import React from 'react';

const Defis = () => {
    return (
        <div>
            <h1>Défis en cours</h1>
            <p>Voici les défis que vous avez actuellement en cours. Restez motivé et atteignez vos objectifs !</p>
            {/* Ajoutez ici la logique pour afficher les défis */}
        </div>
    );
};

export default Defis;